

PyBoolNet is a Python package for the generation, manipulation, and analysis of the interactions and state transitions
of Boolean networks. The project home page is https://sourceforge.net/projects/boolnetfixpoints.

For instructions on installing PyBoolNet see the manual available at the home page.
For a discussion forum and bug reports see the home page.
For any questions, remarks and comments do not hesitate to contact hannes.klarner@fu-berlin.de


release notes for version 1.0 (Feb. 2016)
=========================================
- first official release
