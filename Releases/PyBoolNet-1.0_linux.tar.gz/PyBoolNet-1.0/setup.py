
from distutils.core import setup

import os

package_data_files = []
for root, dirnames, filenames in os.walk('PyBoolNet/Dependencies'):
    root = root.replace('PyBoolNet/Dependencies','Dependencies')
    package_data_files.extend([os.path.join(root,x) for x in filenames])
    

setup(name          = "PyBoolNet",
      version       = "1.0",
      description   = "Python Toolbox for the Generation, Manipulation and Analysis of Boolean Networks.",
      author        = "Hannes Klarner",
      author_email  = "hannes.klarner@fu-berlin.de",
      url           = "http://sourceforge.net/p/boolnetfixpoints",
      packages      = ["PyBoolNet",
                       "PyBoolNet.Tests",],
      package_data  = {'PyBoolNet': package_data_files},
      
      #install_requires = ['networkx>=1.10'],
      #include_package_data = True,
      
      classifiers   = [
          "Programming Language :: Python",
          "Programming Language :: Python :: 2.7",
          "License :: OSI Approved :: GNU Library or Lesser General Public License (LGPL)",
          "Development Status :: 3 - Alpha",
          "Intended Audience :: Science/Research",
          "Natural Language :: English",
          "Topic :: Scientific/Engineering :: Bio-Informatics",
          ],
      requires=['networkx (>=1.10)'],
      )




























