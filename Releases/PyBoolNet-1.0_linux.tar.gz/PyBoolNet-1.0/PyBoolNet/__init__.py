

import AttractorDetection
import FileExchange
import InteractionGraphs
import ModelChecking
import PrimeImplicants
import StateTransitionGraphs
import TemporalQueries
import TrapSpaces
import QuineMcCluskey
import Tests




def version():
    import pkg_resources
    return pkg_resources.get_distribution("PyBoolNet").version





    
